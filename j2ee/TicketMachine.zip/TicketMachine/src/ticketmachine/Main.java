/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ticketmachine;

/**
 *
 * @author rbastide
 */
public class Main {
    public static void main(String[] args) {
        TicketMachine machine = new TicketMachine(50);
        machine.insertMoney(60);
        machine.printTicket();
        machine.refund();
    }
}
